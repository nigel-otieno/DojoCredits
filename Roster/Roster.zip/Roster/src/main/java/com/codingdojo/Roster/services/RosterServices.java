package com.codingdojo.Roster.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.codingdojo.Roster.models.ContactInfo;
import com.codingdojo.Roster.models.Students;
import com.codingdojo.Roster.repository.ContactInfoRepository;
import com.codingdojo.Roster.repository.StudentsRepository;

import java.util.List;

@Service
public class RosterServices {
	@Autowired
	public StudentsRepository studentRepo;
	@Autowired
	public ContactInfoRepository contactRepo;
	
	public Students createStudent(Students student) {
        return studentRepo.save(student);
    }
	
	public ContactInfo createContactInfo(ContactInfo contactInfo) {
        return contactRepo.save(contactInfo);
    }
	
	public List<Students> allStudents(){
		return studentRepo.findAll();
	}
	public List<ContactInfo> allContactInfo(){
		return contactRepo.findAll();
	}
}
